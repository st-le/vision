import os 
import matplotlib.pyplot as plt
import numpy as np 


# Source: https://stackoverflow.com/a/54628145/6004997
def moving_average(x, w):
    return np.convolve(x, np.ones(w), 'valid') / w

def plot_train_losses(logfolder, lognames, legends=None, iou_type='keypoint', colors = ['b','g','r'], ax1=None, ax2=None,
                    plot_box=True,
                    plot_kpt=False
                    ):

    if legends is not None:
        assert len(legends) == len(lognames)

    lns = []
    labs = []
    # labs_ = ('train_loss', 'box_eval_loss','kpt_eval_loss')
    labs_ = ['train', 'bxeval','kpeval']
    if not plot_box:
        labs_.pop(1)
    if not plot_kpt:
        labs_.pop(-1)
    for i, (ln, lg, cl) in enumerate(zip(lognames,legends, colors)):
        logfile = os.path.join(logfolder, ln)

        with open(logfile, 'r') as f:
            lines = f.readlines()

        if iou_type=='keypoint':
            token='loss_keypoint:'
        else:
            raise NotImplementedError()

        losses = []
        box_eval_losses = []
        kpt_eval_losses = []
        for ii, line in enumerate(lines):
            line_ = line.split()

            if "Total" in line_ and  "time:" in line_: 
                continue
            if 'IoU' in line_ and 'metric:' in line_:
                pass
            elif not "Epoch:" in line_ : 
                continue

            # training
            if "Epoch:" in line_:
                if 'loss:' not in line_:
                    continue
                idx = line_.index('Epoch:')
                iter = float(line_[idx+1][1:-1])

                idx = line_.index(token)
                loss_val = float(line_[idx+1])

                losses.append([iter,loss_val])

            # evaluation
            if 'IoU' in line_ and 'metric:' in line_:
                nline = lines[ii+1].strip().split()
                if 'bbox' in line_:
                    value = float(nline[-1])
                    box_eval_losses.append([iter, value])
                if 'keypoints' in line_:
                    value = float(nline[-1])
                    kpt_eval_losses.append([iter, value])
        
        losses=np.array(losses).T
        if plot_box:
            box_eval_losses=np.array(box_eval_losses).T
            box_eval_losses_itp = np.vstack([losses[0], np.interp(losses[0], box_eval_losses[0], box_eval_losses[1])])
        if plot_kpt:
            kpt_eval_losses=np.array(kpt_eval_losses).T
            kpt_eval_losses_itp = np.vstack([losses[0], np.interp(losses[0], kpt_eval_losses[0], kpt_eval_losses[1])])
        # plt.plot(moving_average(losses[1], 30), label=legends[i])
        # plt.plot(losses[0], losses[1],  #moving_average(losses[1], 30)
        #         losses[0], box_eval_losses_itp[1],
        #         losses[0], kpt_eval_losses_itp[1], label=legends[i])

        # color = 'tab:red'
        if ax1 is None:
            fig, ax1 = plt.subplots()
        l1 = ax1.plot(losses[0], losses[1], cl+'-')
        # ax1.plot(losses[0], np.interp(losses[0], moving_average(losses[1], 30)), cl+'-')
        # ax1.plot(losses[0], np.interp(losses[0], , moving_average(losses[1], 30)), cl+'-')
        ax1.tick_params(axis='y')
        # plt.legend(l1, ('train_loss'), loc='upper right', shadow=True)

        if ax2 is None:
            ax2 = ax1.twinx()  
        # color = 'tab:blue'
        # ax2.set_ylabel('sin', color=color)  # we already handled the x-label with ax1
        # l2, l3 = ax2.plot(losses[0], box_eval_losses_itp[1], cl+'--', losses[0], kpt_eval_losses_itp[1], cl+'-.')
        if plot_box:
            l2 = ax2.plot(losses[0], box_eval_losses_itp[1], cl+'--')
        if plot_kpt:
            l3 = ax2.plot(losses[0], kpt_eval_losses_itp[1], cl+'-.')
        ax2.tick_params(axis='y')

        # plt.legend((l1, l2, l3), ('train_loss', 'box_eval_loss','kpt_eval_loss'), loc='upper right', shadow=True)
        # plt.legend((l2, l3), ('box_eval_loss','kpt_eval_loss'), loc='upper right', shadow=True)
        lns.append(l1[0])
        if plot_box:
            lns.append(l2[0])
        if plot_kpt:
            lns.append(l3[0])
        
        labs.append(lg+','+labs_[0])
        if plot_box:
            labs.append(lg+','+labs_[1])
        if plot_kpt:
            if plot_box:
                labs.append(lg+','+labs_[2])
            else:
                labs.append(lg+','+labs_[1])

    # added these three lines
    # lns = l1+l2+l3
    # labs = ('train_loss', 'box_eval_loss','kpt_eval_loss')#[l.get_label() for l in lns]
    
    # ax1.legend(lns, labs, loc='upper right')
    ax1.legend(lns, labs, loc='center right')

    # plt.title("Keypoint training loss/evaluation")
    plt.title("Training schedule length vs. keypoint task")
    # plt.legend()
    # plt.yscale('log')
    # plt.xscale('log')
    plt.grid()
    plt.show()
    print('Done.')

 
if __name__ == '__main__':

    logfolder = "/media/shawnle/1631a13d-7902-48a3-bef7-d38184d9661c/Documents/2022/Apr/object_detection_toolbox/docs/tabletop/"
    # lognames = ['tabletop_multi_trainlog_100ep.txt', 'tabletop_multi_trainlog_200ep.txt', 'tabletop_multi_trainlog_300ep.txt', 'tabletop_multi_trainlog_600ep.txt']
    # legends = ['100ep', '200ep', '300ep', '600ep']
    # plot_train_losses(logfolder, lognames, legends=legends)

    # lognames = ['pen_marker_50ep_affn_clrjit.txt', 'pen_marker_50ep_affn_clrjit_hflip.txt', 'pen_marker_50ep_affn_clrjit_hflip_resize_24pc.txt']
    # legends = ['affn+clrjit', 'affn+clrjit+hflip', 'affn+clrjit+hflip+rsz25pc'] # affn_clrjit_hflip_rsz50pc
    # legends = ['aff+clj', 'aff+clj+hfl', 'aff+clj+hfl+rs25'] # affn_clrjit_hflip_rsz50pc

    lognames = ['tabletop_pretrained_multi_trainlog_50ep.txt', 'tabletop_pretrained_multi_trainlog_100ep.txt', 'tabletop_pretrained_multi_trainlog_200ep.txt']
    legends = ['50ep', '100ep', '200ep'] 

    colors = ['b','g','r']
    plot_train_losses(logfolder, lognames, legends=legends)
